/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 97.81120824015721, "KoPercent": 2.1887917598427866};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.7305949161581964, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.9958964424092991, 500, 1500, "Select UAE country Code"], "isController": false}, {"data": [0.7986600846262342, 500, 1500, "Get Registration by ID"], "isController": false}, {"data": [0.9666995039228794, 500, 1500, "Get Country List"], "isController": false}, {"data": [0.8264874020749524, 500, 1500, "Get Registration for ID"], "isController": false}, {"data": [0.9962801029582878, 500, 1500, "Get Package configuration"], "isController": false}, {"data": [0.6416977677628336, 500, 1500, "Unique Email Checking"], "isController": false}, {"data": [0.4251497005988024, 500, 1500, "Create Registration"], "isController": false}, {"data": [0.9961116193961573, 500, 1500, "Get ADT TITLE"], "isController": false}, {"data": [0.7789431008954382, 500, 1500, "Get Subscription for new Registration ID"], "isController": false}, {"data": [0.006170662905500705, 500, 1500, "Corporate Registration Transaction"], "isController": true}, {"data": [0.8044697664573485, 500, 1500, "Get Subcriptions for Reg Id"], "isController": false}, {"data": [0.6695523648648649, 500, 1500, "IATA Number Checking"], "isController": false}, {"data": [0.7325163110562511, 500, 1500, "Select Package"], "isController": false}, {"data": [0.9963152327221438, 500, 1500, "Get Package Features"], "isController": false}, {"data": [0.3229762156821229, 500, 1500, "Select Package Transaction"], "isController": true}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 368925, 8075, 2.1887917598427866, 474.370427593686, 2, 4641, 450.0, 1261.0, 1514.0, 2181.950000000008, 204.83554580337676, 1802.0793336331305, 67.79067727422007], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Select UAE country Code", 28390, 0, 0.0, 230.19936597393234, 10, 717, 189.0, 396.0, 427.0, 488.0, 15.79164594673671, 33.6343552830398, 3.8091177234804365], "isController": false}, {"data": ["Get Registration by ID", 28360, 1345, 4.742595204513399, 462.92912552891625, 2, 2485, 437.0, 842.0, 995.0, 1409.0, 15.77159877631079, 27.432905360953278, 3.521203374098875], "isController": false}, {"data": ["Get Country List", 28423, 7, 0.0246279421595187, 301.7722970833487, 22, 982, 307.0, 468.0, 513.0, 597.0, 15.786170508192168, 1258.6380969478964, 3.715299894994446], "isController": false}, {"data": ["Get Registration for ID", 28338, 1343, 4.739219422683322, 440.048309690166, 2, 2574, 412.0, 790.0, 958.0, 1365.9900000000016, 15.760310690237985, 28.293436760661905, 3.518687326584026], "isController": false}, {"data": ["Get Package configuration", 28361, 0, 0.0, 238.26257889355168, 11, 751, 202.0, 398.0, 426.0, 484.9900000000016, 15.775260524581228, 185.20525588526905, 4.31354779969018], "isController": false}, {"data": ["Unique Email Checking", 28402, 0, 0.0, 718.3633546933331, 32, 3061, 731.0, 1289.0, 1515.0, 1953.0, 15.790617808894718, 17.519071805001825, 5.813538001907528], "isController": false}, {"data": ["Create Registration", 28390, 1347, 4.744628390278267, 1110.0784078900954, 79, 4641, 1159.0, 1668.0, 1903.9500000000007, 2391.0, 15.783928635960562, 27.471616644323706, 17.101860312023085], "isController": false}, {"data": ["Get ADT TITLE", 28418, 0, 0.0, 258.3813076219292, 10, 1211, 257.0, 407.0, 436.0, 488.0, 15.788488259749466, 20.10565301827471, 3.669590044746458], "isController": false}, {"data": ["Get Subscription for new Registration ID", 28366, 1345, 4.741592046816612, 478.4643587393343, 2, 3057, 456.0, 901.0, 1064.0, 1486.9900000000016, 15.776233981694316, 18.20254578245332, 3.4452070846224823], "isController": false}, {"data": ["Corporate Registration Transaction", 28360, 1352, 4.767277856135402, 4708.941325810977, 430, 8365, 4861.5, 5968.9000000000015, 6362.950000000001, 7039.960000000006, 15.746711152791404, 1727.9881039082009, 54.886604749360224], "isController": true}, {"data": ["Get Subcriptions for Reg Id", 28346, 1343, 4.737881888097086, 467.1976292951413, 2, 2554, 434.0, 836.0, 1012.0, 1412.0, 15.764119915423436, 21.517747269530524, 3.4425661894497295], "isController": false}, {"data": ["IATA Number Checking", 28416, 0, 0.0, 670.54821227478, 26, 2963, 664.0, 1195.0, 1408.0, 1895.0, 15.796399003608334, 17.37361206154236, 5.715432691412375], "isController": false}, {"data": ["Select Package", 28355, 1345, 4.743431493563746, 550.7673778874982, 20, 2926, 513.0, 928.0, 1094.0, 1559.0, 15.769537291577103, 21.49822761287413, 5.907732599979868], "isController": false}, {"data": ["Get Package Features", 28360, 0, 0.0, 239.45624118476718, 9, 985, 205.0, 399.0, 429.0, 487.0, 15.774677970740086, 126.5055229450367, 3.9128595747734196], "isController": false}, {"data": ["Select Package Transaction", 28338, 1343, 4.739219422683322, 1458.0574140729805, 38, 4982, 1373.0, 2403.0, 2728.9500000000007, 3360.9900000000016, 15.759618272214622, 71.28871057384296, 12.864136039532516], "isController": true}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["502/Bad Gateway", 7, 0.08668730650154799, 0.0018974046215355425], "isController": false}, {"data": ["500/Internal Server Error", 2692, 33.3374613003096, 0.7296876058819544], "isController": false}, {"data": ["403/Forbidden", 2688, 33.28792569659443, 0.7286033746696483], "isController": false}, {"data": ["404/Not Found", 2688, 33.28792569659443, 0.7286033746696483], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 368925, 8075, "500/Internal Server Error", 2692, "403/Forbidden", 2688, "404/Not Found", 2688, "502/Bad Gateway", 7, "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": ["Get Registration by ID", 28360, 1345, "403/Forbidden", 1345, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Get Country List", 28423, 7, "502/Bad Gateway", 7, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Get Registration for ID", 28338, 1343, "403/Forbidden", 1343, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Create Registration", 28390, 1347, "500/Internal Server Error", 1347, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Get Subscription for new Registration ID", 28366, 1345, "404/Not Found", 1345, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Get Subcriptions for Reg Id", 28346, 1343, "404/Not Found", 1343, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Select Package", 28355, 1345, "500/Internal Server Error", 1345, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
