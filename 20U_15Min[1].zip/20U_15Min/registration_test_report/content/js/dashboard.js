/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 98.98920794581169, "KoPercent": 1.0107920541883155};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.9498707237334131, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [1.0, 500, 1500, "Select UAE country Code"], "isController": false}, {"data": [0.9780761523046092, 500, 1500, "Get Registration by ID"], "isController": false}, {"data": [0.9997998558962453, 500, 1500, "Get Country List"], "isController": false}, {"data": [0.9781109685695959, 500, 1500, "Get Registration for ID"], "isController": false}, {"data": [1.0, 500, 1500, "Get Package configuration"], "isController": false}, {"data": [0.9998798558269923, 500, 1500, "Unique Email Checking"], "isController": false}, {"data": [0.969398381799247, 500, 1500, "Create Registration"], "isController": false}, {"data": [1.0, 500, 1500, "Get ADT TITLE"], "isController": false}, {"data": [0.978125, 500, 1500, "Get Subscription for new Registration ID"], "isController": false}, {"data": [0.4375951903807615, 500, 1500, "Corporate Registration Transaction"], "isController": true}, {"data": [0.9780726368956947, 500, 1500, "Get Subcriptions for Reg Id"], "isController": false}, {"data": [1.0, 500, 1500, "IATA Number Checking"], "isController": false}, {"data": [0.9780761523046092, 500, 1500, "Select Package"], "isController": false}, {"data": [1.0, 500, 1500, "Get Package Features"], "isController": false}, {"data": [0.9506494547787043, 500, 1500, "Select Package Transaction"], "isController": true}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 162249, 1640, 1.0107920541883155, 110.02277980141635, 2, 893, 81.0, 157.0, 216.0, 328.9900000000016, 180.28207512892052, 1586.8065549344954, 59.67430216482884], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["Select UAE country Code", 12483, 0, 0.0, 85.55467435712498, 11, 450, 78.0, 134.0, 158.0, 211.0, 13.911363119675837, 29.629573207043947, 3.3555729399999334], "isController": false}, {"data": ["Get Registration by ID", 12475, 273, 2.188376753507014, 87.3599198396795, 2, 761, 81.0, 134.0, 158.0, 224.0, 13.908043029645594, 24.508557801436627, 3.107916963617786], "isController": false}, {"data": ["Get Country List", 12491, 2, 0.01601152830037627, 111.00752541830047, 10, 562, 102.0, 166.0, 194.0, 263.0, 13.879474911162916, 1106.7114956138425, 3.266556107021741], "isController": false}, {"data": ["Get Registration for ID", 12472, 273, 2.1889031430404104, 87.05051314945523, 2, 396, 80.0, 134.0, 160.0, 225.27000000000044, 13.908900715072734, 25.307138888687533, 3.1081080515940815], "isController": false}, {"data": ["Get Package configuration", 12479, 0, 0.0, 85.88564788845213, 11, 371, 79.0, 133.0, 156.0, 218.0, 13.909525109930838, 163.30108483553568, 3.8033857722467133], "isController": false}, {"data": ["Unique Email Checking", 12485, 0, 0.0, 120.72951541850237, 21, 843, 109.0, 178.0, 208.0, 295.0, 13.909406702807727, 15.357845920942541, 5.120943678670423], "isController": false}, {"data": ["Create Registration", 12483, 273, 2.1869742850276377, 253.57085636465584, 99, 893, 234.0, 361.0, 414.0, 550.1599999999999, 13.908790070084347, 24.517176679893367, 15.069999474228124], "isController": false}, {"data": ["Get ADT TITLE", 12488, 0, 0.0, 86.94786995515716, 9, 389, 81.0, 133.0, 156.0, 213.0, 13.88609355766654, 17.683072264840984, 3.227431901098278], "isController": false}, {"data": ["Get Subscription for new Registration ID", 12480, 273, 2.1875, 82.9784455128203, 2, 418, 76.0, 132.0, 156.0, 226.0, 13.910686260522185, 16.148970358074774, 3.040585304942752], "isController": false}, {"data": ["Corporate Registration Transaction", 12475, 275, 2.2044088176352705, 1116.3395591182411, 550, 2906, 1025.0, 1508.3999999999996, 1679.0, 2196.24, 13.861126512362791, 1521.812955009186, 48.31945798516165], "isController": true}, {"data": ["Get Subcriptions for Reg Id", 12473, 273, 2.188727651727732, 94.12426841978663, 2, 878, 87.0, 144.0, 168.0, 231.0, 13.909550563050757, 19.163580571096727, 3.040335731140755], "isController": false}, {"data": ["IATA Number Checking", 12488, 0, 0.0, 117.42024343369678, 31, 441, 107.0, 172.0, 201.0, 275.0, 13.908611689337214, 15.295626694652624, 5.032245343029155], "isController": false}, {"data": ["Select Package", 12475, 273, 2.188376753507014, 132.8451302605209, 15, 520, 124.0, 188.0, 211.0, 276.0, 13.908291125339623, 19.12914813389197, 5.21323131411332], "isController": false}, {"data": ["Get Package Features", 12477, 0, 0.0, 84.76620982608019, 10, 387, 78.0, 131.0, 156.0, 216.0, 13.907900427592418, 111.53484210096576, 3.4498112388754634], "isController": false}, {"data": ["Select Package Transaction", 12472, 273, 2.1889031430404104, 314.02918537524107, 22, 1265, 293.0, 443.0, 510.0, 655.2700000000004, 13.905907669322154, 63.586077829445806, 11.359315854318], "isController": true}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["502/Bad Gateway", 2, 0.12195121951219512, 0.0012326732368150189], "isController": false}, {"data": ["500/Internal Server Error", 546, 33.292682926829265, 0.33651979365050017], "isController": false}, {"data": ["403/Forbidden", 546, 33.292682926829265, 0.33651979365050017], "isController": false}, {"data": ["404/Not Found", 546, 33.292682926829265, 0.33651979365050017], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 162249, 1640, "500/Internal Server Error", 546, "403/Forbidden", 546, "404/Not Found", 546, "502/Bad Gateway", 2, "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": ["Get Registration by ID", 12475, 273, "403/Forbidden", 273, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Get Country List", 12491, 2, "502/Bad Gateway", 2, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Get Registration for ID", 12472, 273, "403/Forbidden", 273, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Create Registration", 12483, 273, "500/Internal Server Error", 273, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Get Subscription for new Registration ID", 12480, 273, "404/Not Found", 273, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Get Subcriptions for Reg Id", 12473, 273, "404/Not Found", 273, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["Select Package", 12475, 273, "500/Internal Server Error", 273, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
